(function tryUnmuteAndPlay() {
  const video = document.querySelector("video");
  if (!video) {
    setTimeout(tryUnmuteAndPlay, 1000);
    return;
  }

  if (video.muted) {
    console.log("[TTM] Unmuting stream.");
    video.muted = false;
  }

  if (video.paused) {
    console.log("[TTM] Resuming playback.");
    video.play().catch(e => console.warn("[TTM] Failed to play video:", e));
  }
})();
