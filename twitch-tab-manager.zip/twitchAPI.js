import { loadConfig } from './loadConfig.js';

export async function checkStreamers(streamers) {
  const config = await loadConfig();
  const { access_token, client_id } = config;

  if (!access_token || !client_id) {
    console.warn("[TwitchAPI] Missing access_token or client_id in config.");
    return [];
  }

  const loginParams = streamers.map(username => `user_login=${username}`).join('&');
  const url = `https://api.twitch.tv/helix/streams?${loginParams}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Client-ID': client_id,
        'Authorization': `Bearer ${access_token}`
      }
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("[TwitchAPI] Failed response:", response.status, errText);
      return [];
    }

    const data = await response.json();
    console.log("[TwitchAPI] Online streamers:", data.data.map(s => s.user_name).join(', ') || 'None');
    return data.data; // Array of live stream objects

  } catch (err) {
    console.error("[TwitchAPI] Fetch failed:", err);
    return [];
  }
}
export async function getLiveStreamersFromDOM(config) {
  const clientId = config.client_id;
  const accessToken = config.access_token;
  const usernames = config.follows || [];

  const liveStreamers = [];

  for (const login of usernames) {
    try {
      const url = `https://api.twitch.tv/helix/streams?user_login=${login}`;
      const res = await fetch(url, {
        headers: {
          'Client-ID': clientId,
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (!res.ok) {
        console.warn(`⚠️ Failed to fetch stream status for ${login}`);
        continue;
      }

      const data = await res.json();
      if (data.data && data.data.length > 0) {
        liveStreamers.push(login);
      }
    } catch (err) {
      console.error(`Error checking live status for ${login}:`, err);
    }
  }

  return liveStreamers;
}

