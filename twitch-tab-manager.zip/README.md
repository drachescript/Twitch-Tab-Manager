# Twitch Tab Manager

Automatically opens followed Twitch streams in background tabs and closes inactive or unfollowed streams after a configurable timeout.

---

## 🚀 Features

- ✅ Automatically open Twitch streams from your `follows.txt`
- ❌ Close inactive or unfollowed streams after 1 minute (configurable)
- 🔊 Optional unmute & resume playback
- 🧼 Ignores Twitch system tabs (drops, inventory, settings, moderator, etc.)
- ⚙️ Fully configurable via `config.json`
- 👥 Does not require login or Twitch OAuth
- 🧪 Lightweight and safe (no suspicious automation)

---

## 📁 Setup Instructions

1. **Download the Extension Folder**

   - Make sure all the following files exist:
     - `manifest.json`
     - `background.js`
     - `tabManager.js`
     - `loadConfig.js`
     - `content_unmute.js`
     - `follows.txt`
     - `config.json`

2. **Edit `follows.txt`**

   List one Twitch username per line. Example:

- pokimane
- xqc


3. **Edit `config.json`**

Example:

```json
{
  "check_interval_sec": 60,
  "force_unmute": true,
  "force_resume": true,
  "unmute_streams": true,
  "max_tabs": 8
}

4. Load the Extension in Chrome:

Go to chrome://extensions/

Enable Developer mode (top right)

Click "Load unpacked" and select the folder

Done — Twitch tabs will now auto-manage themselves!

