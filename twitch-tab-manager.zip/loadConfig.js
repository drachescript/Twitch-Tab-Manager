// loadConfig.js

async function loadConfig() {
  const config = await fetch(chrome.runtime.getURL('config.json'))
    .then(res => res.json());

  const follows = await fetch(chrome.runtime.getURL('follows.txt'))
    .then(res => res.text())
    .then(text => text
      .split('\n')
      .map(s => s.trim().toLowerCase())
      .filter(Boolean)
    );

  return {
    client_id: config.client_id,
    access_token: config.access_token,
    follows
  };
}
