document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggleManager');
  const statusText = document.getElementById('statusText');

  // Load initial state
  chrome.storage.local.get('enabled', data => {
    toggle.checked = !!data.enabled;
    statusText.innerHTML = `Extension is <strong>${data.enabled ? 'on' : 'off'}</strong>`;
  });

  // Save toggle state
  toggle.addEventListener('change', () => {
    const enabled = toggle.checked;
    chrome.storage.local.set({ enabled }, () => {
      statusText.innerHTML = `Extension is <strong>${enabled ? 'on' : 'off'}</strong>`;
      // Tell the background service to act immediately
      chrome.runtime.sendMessage({ type: 'TOGGLE_BOT' });
    });
  });
});
