import { openStreamTab, closeStreamTab, recoverOpenTabs } from "./tabManager.js";
import { loadConfig } from "./loadConfig.js";

let config = null;
let trackedLive = new Set();
const openTabTimestamps = new Map();

const IGNORED_PATHS = [
  "/drops",
  "/drops/inventory",
  "/settings/connections"
];

const MODERATOR_PATH_PREFIX = "/moderator/";
const EXCLUDED_DOMAINS = ["https://crosspilot.io/"];

function isSystemTwitchTab(pathname) {
  return IGNORED_PATHS.includes(pathname) || pathname.startsWith(MODERATOR_PATH_PREFIX);
}

async function closeUnfollowedTwitchTabs() {
  const tabs = await chrome.tabs.query({ url: "*://www.twitch.tv/*" });
  const now = Date.now();

  for (const tab of tabs) {
    let url;
    try {
      url = new URL(tab.url);
    } catch (e) {
      console.warn(`Skipping invalid tab URL: ${tab.url}`);
      continue;
    }

    if (isSystemTwitchTab(url.pathname)) continue;

    const username = url.pathname.split("/")[1]?.toLowerCase();
    if (!username || username === "videos" || username === "directory") continue;

    const isFollowed = config.follows.includes(username);
    const openedAt = openTabTimestamps.get(tab.id) || now;
    const age = now - openedAt;

    if (!openTabTimestamps.has(tab.id)) {
      openTabTimestamps.set(tab.id, now);
      console.log(`👀 Tracking tab: ${username}, id: ${tab.id}`);
    }

    if (!isFollowed && age > 60000) {
      console.log(`❌ Closing unfollowed tab: ${tab.url} (age: ${Math.round(age / 1000)}s)`);
      chrome.tabs.remove(tab.id);
      openTabTimestamps.delete(tab.id);
    }
  }

  // Clean up
  const tabIds = new Set(tabs.map(t => t.id));
  for (const tabId of openTabTimestamps.keys()) {
    if (!tabIds.has(tabId)) openTabTimestamps.delete(tabId);
  }
}

async function closeExcludedDomainTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (EXCLUDED_DOMAINS.some(domain => tab.url?.startsWith(domain))) {
      console.log(`🧹 Closing excluded tab: ${tab.url}`);
      chrome.tabs.remove(tab.id);
    }
  }
}

async function checkStreamers(clientId, accessToken, users) {
  if (!users.length) return new Set();

  const loginList = users.map(u => `user_login=${u}`).join("&");
  const url = `https://api.twitch.tv/helix/streams?${loginList}`;

  const res = await fetch(url, {
    headers: {
      "Client-ID": clientId,
      "Authorization": `Bearer ${accessToken}`
    }
  });

  if (!res.ok) {
    const error = await res.text();
    throw new Error(`❌ Invalid Twitch API response: ${error}`);
  }

  const json = await res.json();
  return new Set(json.data.map(s => s.user_login.toLowerCase()));
}

async function pollTwitch() {
  if (!config) return;

  try {
    const liveNow = await checkStreamers(config.client_id, config.access_token, config.follows);

    const toOpen = config.follows.filter(u => liveNow.has(u) && !trackedLive.has(u));
    const toClose = [...trackedLive].filter(u => !liveNow.has(u));

    for (const username of toOpen) {
      console.log(`✅ LIVE: ${username}`);
      openStreamTab(username);
    }

    for (const username of toClose) {
      console.log(`❌ OFFLINE: ${username}`);
      closeStreamTab(username);
    }

    trackedLive = liveNow;
    await closeUnfollowedTwitchTabs();
    await closeExcludedDomainTabs();
  } catch (err) {
    console.error("Polling error:", err);
  }
}

chrome.runtime.onInstalled.addListener(() => {
  console.log("Twitch Tab Manager installed.");
  chrome.alarms.create("pollTwitch", { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(() => {
  console.log("Twitch Tab Manager started.");
  recoverOpenTabs();
  chrome.alarms.create("pollTwitch", { periodInMinutes: 1 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pollTwitch") {
    pollTwitch();
  }
});

(async () => {
  config = await loadConfig();
  console.log("✅ Config loaded:", config);
  recoverOpenTabs();
  pollTwitch();
})();
