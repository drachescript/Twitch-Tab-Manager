const openTabs = {};
let config = null;

// Load config (used for shouldUnmute etc.)
async function loadConfig() {
  const url = chrome.runtime.getURL("config.json");
  const res = await fetch(url);
  config = await res.json();
}

// Open a stream tab if not already open
function openStreamTab(username) {
  chrome.tabs.query({}, async (tabs) => {
    const alreadyOpen = tabs.some(tab => tab.url?.includes(`twitch.tv/${username}`));

    if (!alreadyOpen) {
      chrome.tabs.create({ url: `https://www.twitch.tv/${username}`, active: true }, (tab) => {
        if (tab?.id) {
          openTabs[username] = tab.id;
          chrome.storage.local.set({ openTabs });
          setTimeout(() => attemptFixPlayback(tab.id), 8000); // Give Twitch time to load
        }
      });
    } else {
      const tab = tabs.find(t => t.url?.includes(`twitch.tv/${username}`));
      if (tab?.id) {
        openTabs[username] = tab.id;
        chrome.storage.local.set({ openTabs });
        attemptFixPlayback(tab.id);
      }
    }
  });
}

// Close a stream tab
function closeStreamTab(username) {
  const tabId = openTabs[username];
  if (tabId !== undefined) {
    chrome.tabs.remove(tabId, () => {
      if (chrome.runtime.lastError) {
        console.warn(`⚠️ Could not close tab ${tabId}:`, chrome.runtime.lastError.message);
      }
      delete openTabs[username];
      chrome.storage.local.set({ openTabs });
    });
  }
}

// Try to resume video playback and unmute
function attemptFixPlayback(tabId) {
  if (!config) return;

  chrome.scripting.executeScript({
    target: { tabId },
    func: (shouldUnmute) => {
      const video = document.querySelector('video');
      if (video) {
        if (video.paused) {
          video.play().catch(err => console.warn("🔇 Playback resume error:", err));
        }
        if (shouldUnmute && video.muted) {
          video.muted = false;
        }
      }
    },
    args: [config.unmute_streams ?? true]
  }, (results) => {
    if (chrome.runtime.lastError) {
      console.warn(`⚠️ Script injection failed in tab ${tabId}:`, chrome.runtime.lastError.message);
    }
  });
}

// On extension start/reload, recover previous state
function recoverOpenTabs() {
  chrome.storage.local.get('openTabs', data => {
    const storedTabs = data.openTabs || {};
    Object.entries(storedTabs).forEach(([username, tabId]) => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab?.url?.includes(`twitch.tv/${username}`)) {
          delete storedTabs[username];
        } else {
          openTabs[username] = tabId;
        }
        chrome.storage.local.set({ openTabs: storedTabs });
      });
    });
  });
}

// Call loadConfig once at startup
loadConfig();

export { openStreamTab, closeStreamTab, recoverOpenTabs };
